<?php
/**
 * Simple footer.
 *
 * @package          Flatsome\Templates
 * @flatsome-version 3.16.0
 */

get_template_part( 'template-parts/footer/footer-absolute' );
